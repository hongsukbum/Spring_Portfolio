package com.portfolio.spring.dao;

import java.util.ArrayList;

import com.portfolio.spring.dto.ProductCateDto;

public interface ProductCateDao {

	public ArrayList<ProductCateDto> productCateList();
	
}
